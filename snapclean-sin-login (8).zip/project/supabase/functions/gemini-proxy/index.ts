const PRIMARY_MODEL = "gemini-3.6-flash";
const FALLBACK_MODEL = "gemini-3.6-flash";
const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY") ?? "";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const BUSY_STATUS = new Set([429, 503, 504]);
const RETRYABLE_STATUS = new Set([429, 503]);
const MAX_RETRIES = 1;
const BACKOFF_MS = 1500;
const TIMEOUT_MS = 25000; // máximo por llamada a Gemini

type GeminiResult = { ok: boolean; status: number; data: unknown; message: string };

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function geminiMessage(text: string): string {
  try {
    const m = JSON.parse(text)?.error?.message;
    return typeof m === "string" ? m.slice(0, 200) : "";
  } catch {
    return "";
  }
}

async function callGemini(model: string, body: unknown): Promise<GeminiResult> {
  // La clave va en una cabecera, no en la URL, para que no salga en los registros
  const url = `https://generativelanguage.googleapis.com/v1/models/${model}:generateContent`;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": GEMINI_API_KEY },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    const text = await res.text().catch(() => "");
    if (!res.ok) return { ok: false, status: res.status, data: null, message: geminiMessage(text) };
    try {
      return { ok: true, status: res.status, data: JSON.parse(text), message: "" };
    } catch {
      return { ok: false, status: 502, data: null, message: "Respuesta no válida de Gemini" };
    }
  } catch (err) {
    const timedOut = err instanceof DOMException && (err.name === "TimeoutError" || err.name === "AbortError");
    return { ok: false, status: timedOut ? 504 : 0, data: null, message: timedOut ? "Gemini tardó demasiado" : "Error de red" };
  }
}

async function callWithRetries(model: string, body: unknown): Promise<GeminiResult> {
  let last: GeminiResult = { ok: false, status: 500, data: null, message: "" };
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    last = await callGemini(model, body);
    if (last.ok) return last;
    if (!(RETRYABLE_STATUS.has(last.status) || last.status === 0) || attempt === MAX_RETRIES) return last;
    await sleep(BACKOFF_MS);
  }
  return last;
}

const json = (obj: unknown, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  if (!GEMINI_API_KEY) {
    return json({ error: "GEMINI_ERROR", message: "Falta el secreto GEMINI_API_KEY en Supabase." }, 500);
  }

  try {
    const body = await req.json();

    const primary = await callWithRetries(PRIMARY_MODEL, body);
    if (primary.ok) return json(primary.data);

    // Solo se prueba otro modelo si es distinto del primero
    const fallback = FALLBACK_MODEL !== PRIMARY_MODEL ? await callWithRetries(FALLBACK_MODEL, body) : primary;
    if (fallback.ok) return json(fallback.data);

    if (BUSY_STATUS.has(primary.status) && BUSY_STATUS.has(fallback.status)) {
      return json({ error: "OVERLOADED", message: "El servicio está muy ocupado, inténtalo de nuevo en unos segundos." }, 503);
    }

    return json({
      error: "GEMINI_ERROR",
      message: "La IA no pudo responder. Inténtalo de nuevo más tarde.",
      detail: `${PRIMARY_MODEL}: ${primary.status} ${primary.message}`.trim(),
    }, 502);
  } catch {
    return json({ error: "GEMINI_ERROR", message: "La IA no pudo responder. Inténtalo de nuevo más tarde." }, 502);
  }
});
